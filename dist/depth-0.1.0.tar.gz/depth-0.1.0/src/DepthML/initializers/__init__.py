from .he import He
from .xavier import Xavier

from .uniform import Uniform