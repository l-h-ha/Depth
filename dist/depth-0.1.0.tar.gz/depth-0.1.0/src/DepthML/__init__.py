from DepthTensor import Tensor

from .components import activation, layer, loss

__version__ = "0.1.0"